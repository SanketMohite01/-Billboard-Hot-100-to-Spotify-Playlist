import requests
from bs4 import BeautifulSoup
import spotipy
from spotipy.oauth2 import SpotifyOAuth

# ------------------- INPUT DATE ------------------- #
date = input("Which year do you want to travel to? Type the date in this format YYYY-MM-DD: ")
year = date.split("-")[0]

# ------------------- SCRAPE BILLBOARD SONGS ------------------- #
URL = f"https://www.billboard.com/charts/hot-100/{date}"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}

response = requests.get(URL, headers=headers)
soup = BeautifulSoup(response.text, "html.parser")

song_tags = soup.select("li ul li h3")
all_songs = [song.get_text(strip=True) for song in song_tags]
all_songs.reverse()

print(f"\n🎵 Found {len(all_songs)} songs for {date}")
for i, song in enumerate(all_songs, start=1):
    print(f"{i}. {song}")

# ------------------- SPOTIFY AUTH ------------------- #
CLIENT_ID = "a79ab888b0064c3da7e7107ff6a0f38a"
CLIENT_SECRET = "9498deccef204273bd4250dc7caeea56"
REDIRECT_URI = "https://localhost:8888/callback"  # Make sure this is set in your Spotify Dashboard

SCOPE = "playlist-modify-private"

sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    redirect_uri="http://127.0.0.1:8888/callback",
    scope=SCOPE,
    show_dialog=True,
    cache_path="token.txt"
))


# ------------------- GET USER ID ------------------- #
user_id = sp.current_user()["id"]
print(f"\n✅ Successfully logged in as: {user_id}")

# ------------------- SEARCH SONGS ON SPOTIFY ------------------- #
song_uris = []
for song in all_songs:
    result = sp.search(q=f"track:{song} year:{year}", type="track", limit=1)
    try:
        uri = result["tracks"]["items"][0]["uri"]
        song_uris.append(uri)
    except IndexError:
        print(f"❌ '{song}' not found on Spotify. Skipping...")

# ------------------- CREATE PLAYLIST ------------------- #
playlist = sp.user_playlist_create(
    user=user_id,
    name=f"Billboard Top 100 - {date}",
    public=False,
    description=f"Top 100 songs from Billboard on {date}"
)
print(f"\n✅ Created playlist: {playlist['name']}")

# ------------------- ADD SONGS TO PLAYLIST ------------------- #
sp.playlist_add_items(playlist_id=playlist["id"], items=song_uris)
print("🎧 Songs successfully added to your playlist!")
